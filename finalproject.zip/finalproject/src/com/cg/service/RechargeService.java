package com.cg.service;

public interface RechargeService 
{

	
}
