package com.cg.beans;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.sun.xml.internal.ws.developer.Serialization;
@Entity
@Serialization
public class Customer 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int rechargeId;
	private String name;
	private Double phoneNo;
	private String plan;
	private String description;
    private Double openingBalance;
    private LocalDate date;
	public int getRechargeId() {
		return rechargeId;
	}
	public void setRechargeId(int rechargeId) {
		this.rechargeId = rechargeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Double phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getPlan() {
		return plan;
	}
	public void setPlan(String plan) {
		this.plan = plan;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Double getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(Double openingBalance) {
		this.openingBalance = openingBalance;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public Customer(int rechargeId, String name, Double phoneNo, String plan, String description, Double openingBalance,
			LocalDate date) {
		super();
		this.rechargeId = rechargeId;
		this.name = name;
		this.phoneNo = phoneNo;
		this.plan = plan;
		this.description = description;
		this.openingBalance = openingBalance;
		this.date = date;
	}
	
    
	public Customer()
	{
		
	}
	@Override
	public String toString() {
		return "Customer [rechargeId=" + rechargeId + ", name=" + name + ", phoneNo=" + phoneNo + ", plan=" + plan
				+ ", description=" + description + ", openingBalance=" + openingBalance + ", date=" + date + "]";
	}
	
	
}
