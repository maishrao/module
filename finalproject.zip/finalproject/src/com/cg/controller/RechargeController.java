package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RechargeController
{

	
	@RequestMapping("/index")
	public String getHomePage(Model model)
	{
		return "index";
	}
	
	
	@RequestMapping("/Recharge")
	public String Recharge(Model model)
	{
		return "Recharge";
	}
	
	@RequestMapping("/transactions")
	public String transactions(Model model)
	{
		return "transaction";
	}
	
	@RequestMapping("/specific_transaction")
	public String specific_transaction(Model model)
	{
		return "specific_transaction";
	}
	
	@RequestMapping("/Offers")
	public String Offers(Model model)
	{
		return "Offers";
	}
	
}
